#include <stdio.h>

#include "creditos.c"
#include "msg.c"
#include "testetela.c"
#include "score.c"
#include "inicio2.c"
#include "FlappyBird.c"
//acimas includes NATANAEL



void main(void){
	menu();

}
