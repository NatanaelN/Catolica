#include <stdio.h>

#include "creditos.c"
#include "msg.c"
#include "testetela.c"
#include "score.c"
#include "inicio2.c"
#include "main.c"
//acimas includes NATANAEL



void main(void){
	menu();

}
