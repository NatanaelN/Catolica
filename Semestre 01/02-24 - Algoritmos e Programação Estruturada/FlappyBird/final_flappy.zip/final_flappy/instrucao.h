//
// Created by natan on 24/11/2024.
//

#ifndef INSTRUCAO_H
#define INSTRUCAO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "configs.h"
#include "score.h"

void tela_instrucao();

#endif //INSTRUCAO_H
