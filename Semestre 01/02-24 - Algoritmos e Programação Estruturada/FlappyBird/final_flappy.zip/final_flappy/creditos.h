//
// Created by natan on 24/11/2024.
//

#ifndef CREDITOS_H
#define CREDITOS_H

#include <stdio.h>
#include <stdlib.h>

#include "configs.h"

void creditos(void);

#endif //CREDITOS_H
