#ifndef INICIO_H
#define INICIO_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#include "configs.h"
#include "score.h"
#include "instrucao.h"
#include "msg.h"
#include "creditos.h"

void linhacaixa();
void letreiro(void);
void menu();



#endif
