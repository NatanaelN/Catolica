#include <stdio.h>

#include "inicio.h"

int main() {
    menu();

    return 0;
}
