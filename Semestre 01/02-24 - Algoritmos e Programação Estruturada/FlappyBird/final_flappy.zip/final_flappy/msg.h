//
// Created by natan on 24/11/2024.
//

#ifndef MSG_H
#define MSG_H

#include <stdio.h>
#include <stdlib.h>

#include "configs.h"

void msg();

#endif //MSG_H
